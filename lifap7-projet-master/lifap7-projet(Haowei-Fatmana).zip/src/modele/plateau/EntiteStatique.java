package modele.plateau;

/**
 * Ne bouge pas (murs...)
 */
public abstract class EntiteStatique extends Entite {

    public EntiteStatique(Jeu _jeu) {
        super(_jeu);
    }

}
